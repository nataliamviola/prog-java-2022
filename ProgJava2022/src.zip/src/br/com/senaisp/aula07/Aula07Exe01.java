package br.com.senaisp.aula07;

public class Aula07Exe01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Aplicativo para mostrar os n�meros de 1 a 100");
		
		for (int intValor = 1; intValor <=100; intValor ++)
		System.out.println("Os valores s�o:" + intValor);
	}

}
