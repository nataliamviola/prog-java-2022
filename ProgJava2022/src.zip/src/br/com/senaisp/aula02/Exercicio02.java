package br.com.senaisp.aula02;

public class Exercicio02 {

	public static void main(String[] args) {
		//Feito
		
		
	    double divisao = 1.00 / 5.00;
		System.out.println("Resultado da primeira express�o �:" + divisao);
		double divisaol = 3.00 / 4.00;
		System.out.println("Resultado da primeira express�o �:" + divisaol);
		double mutiplicacao = divisao * divisaol;
		System.out.println("Mutiplicando as divis�es:" + mutiplicacao);
		double somaf = mutiplicacao + 5;
		System.out.println("Total: " + somaf);
	}

}
